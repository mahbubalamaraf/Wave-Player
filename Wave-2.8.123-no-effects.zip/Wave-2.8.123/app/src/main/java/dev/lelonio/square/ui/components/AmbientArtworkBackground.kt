package dev.lelonio.square.ui.components

import android.content.Context
import android.os.PowerManager
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.GraphicsLayerScope
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import coil.compose.AsyncImage
import coil.imageLoader
import coil.request.ImageRequest
import dev.lelonio.square.ui.theme.warmArtworkColor
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull

/**
 * The room the player is in, made out of the record that is playing.
 *
 * Not a blurred cover behind a cover. The same picture is drawn much larger
 * than the screen, blurred past the point where anything in it can be made
 * out, and left as light and colour: what reaches the eye is the record's
 * palette filling the window, with the sharp copy above dissolving into it —
 * see [HeroBackdrop]'s `fadeToPage`, which is the other half of this.
 *
 * Three things make it read as a room rather than as a wallpaper:
 *
 * - two copies at different blurs, the softer one filling the frame and the
 *   sharper one over it at low opacity, which gives the field a near and a far
 *   and stops it looking like flat paper;
 * - a drift so slow it is never caught moving, which is what keeps a still
 *   screen from looking switched off;
 * - a crossfade on a track change that is slower than the cover's own, so the
 *   room changes around the picture instead of with it.
 *
 * ## What this deliberately does not do
 *
 * There is no `Modifier.blur` here and no `RenderEffect`. Both are render
 * effects over a layer, re-run every frame that layer changes — and this layer
 * changes on every frame of the drift, of the crossfade, and of the player
 * opening. The blur is done once per cover, at decode, on an image small enough
 * that the work is trivial, and Coil keeps the result: see [BlurTransformation].
 * That also settles the compatibility question, since it is ordinary bitmap
 * work on every version the app runs on.
 *
 * Everything that animates is read inside a `graphicsLayer` block, which the
 * compose runtime defers to the draw phase: the drift and the crossfade never
 * recompose anything and never re-decode anything. They move a texture the GPU
 * already has.
 */
@Composable
fun AmbientArtworkBackground(
    /** Usually a url; anything Coil can load. */
    artworkModel: Any?,
    /**
     * The colour taken from this same picture, which the field settles onto at
     * the foot of the screen and which is what is showing before it loads.
     */
    tone: Color,
    modifier: Modifier = Modifier,
    /** Off leaves the tone alone, which is the whole of the fallback. */
    enabled: Boolean = true,
    /**
     * The proportions the sharp cover above is drawn at, width over height.
     *
     * Given, this copy is laid over that cover exactly and its foot carried on
     * down the rest of the screen. Null fills the window with the picture
     * instead, which is right where there is no cover over this to match.
     */
    coverAspect: Float? = null,
    /**
     * The height of the picture above, where the page fixes it rather than
     * letting it take its own proportions. Wins over [coverAspect].
     */
    coverHeight: Dp? = null,
    /**
     * How the copy is framed, which has to be how the sharp picture above is
     * framed.
     *
     * The player draws its cover at its own proportions and fills the window,
     * so stretching to the bounds keeps every row under the row above it. A
     * page lays the picture across a short wide header and crops it, and a copy
     * stretched instead of cropped is a different framing of the same photo —
     * which arrives as a band of blurred something-else under the header.
     */
    coverScale: ContentScale = ContentScale.FillBounds,
    /**
     * Where the field starts settling — usually the foot of the picture.
     *
     * A page carries a list over this and needs to be darker than a player
     * does, and it needs to be darker from where its header ends rather than
     * from halfway down a screen it does not control.
     */
    settleFrom: Float = 0.55f,
    /**
     * Where the settling is complete, after which the field is one flat colour
     * and stays it.
     *
     * A page holds a single tone under its lists rather than sliding towards
     * black: the slide is what made every page look like it was running out of
     * light towards the bottom.
     */
    settleTo: Float = 1f,
    /** How much of the tone, and of black, has arrived by [settleTo]. */
    toneFloor: Float = 0.26f,
    scrimFloor: Float = 0.34f,
    /**
     * Whether the field drifts.
     *
     * Worth switching off while the player is arriving or leaving: the drift is
     * cheap, but it is also invisible under a travelling sheet, and a
     * continuously invalidating background during that travel is the one moment
     * this could cost a frame.
     */
    motion: Boolean = true,
    /**
     * The foot of a moving picture, across its width — see CanvasSurface.
     *
     * When a Canvas is playing, the picture the screen is made of is the clip,
     * not the sleeve, and the field under it has to be the clip's. These are
     * column averages of the clip's own bottom band, painted across the width
     * the way the still copy's last row is carried down: a red shape at the
     * foot of the frame goes on being red under it, and a dark corner stays
     * dark. Empty puts the cover's own copies back.
     */
    columns: List<Color> = emptyList(),
) {
    // Artwork blur/ambient image processing removed for performance.
    // Keep the theme-derived base tone so the player layout remains intact.
    Box(modifier.fillMaxSize().background(tone))
}

/**
 * One blurred copy of the artwork, and the one leaving fading out under it.
 *
 * [progress] and [drift] are functions rather than values: read as parameters
 * they would recompose this on every frame of both animations, and read inside
 * the `graphicsLayer` block they are draw-phase reads, which is a re-record of
 * one layer and nothing else.
 */
@Composable
private fun AmbientCopy(
    leaving: Any?,
    shown: Any?,
    progress: () -> Float,
    drift: () -> Float,
    decodePx: Int,
    blur: BlurTransformation,
    baseScale: Float,
    travel: Float,
    opacity: Float,
    /** Vertical stretch about the foot; see SMEAR. */
    stretch: Float = 1f,
    /** How the picture is framed in its box; see coverScale. */
    scale: ContentScale = ContentScale.FillBounds,
) {
    if (leaving != null) {
        AmbientImage(
            model = leaving,
            decodePx = decodePx,
            blur = blur,
            scale = scale,
            layer = {
                val p = progress()
                alpha = (1f - p) * opacity
                // The picture leaving grows very slightly as it goes, which
                // reads as it receding rather than as it being switched off.
                val scale = baseScale * (1f + LEAVE_SWELL * p)
                scaleX = scale
                scaleY = scale * stretch
                transformOrigin = if (stretch > 1f) SmearAnchor else FootAnchor
                translationY = size.height * travel * drift()
            },
        )
    }
    if (shown != null) {
        AmbientImage(
            model = shown,
            decodePx = decodePx,
            blur = blur,
            scale = scale,
            layer = {
                val p = progress()
                alpha = p * opacity
                // And the one arriving settles inward to its own size.
                val scale = baseScale * (1f + ARRIVE_SWELL * (1f - p))
                scaleX = scale
                scaleY = scale * stretch
                transformOrigin = if (stretch > 1f) SmearAnchor else FootAnchor
                translationY = size.height * travel * drift()
            },
        )
    }
}

/**
 * The tone coming up under the picture, eased, and then holding.
 *
 * Smoothstepped for the same reason the picture's own fade is: a straight ramp
 * between two stops has a corner at each end, and a corner in a field this
 * large is a band across the page. Past [to] the colour is simply itself, which
 * is what makes the lower half of a page one colour rather than a slide into
 * the dark.
 */
private fun tonalSettle(
    from: Float,
    to: Float,
    colour: Color,
    ceiling: Float,
): Array<Pair<Float, Color>> {
    val steps = 8
    val end = to.coerceIn(from + 0.01f, 1f)
    // The flat run past the end of the ramp, unless the ramp already ends at
    // the bottom of the screen: two stops at the same place is a hard edge.
    val hold = if (end < 0.999f) 1 else 0
    return Array(steps + 1 + hold) { index ->
        if (index > steps) return@Array 1f to colour.copy(alpha = ceiling)
        val t = index.toFloat() / steps
        val eased = t * t * (3f - 2f * t)
        (from + (end - from) * t) to colour.copy(alpha = ceiling * eased)
    }
}

/**
 * Puts a copy in Coil's cache, at the size and blur a copy below will ask for.
 *
 * The result is thrown away on purpose: what is wanted is the cache entry, so
 * that the image the crossfade is about to draw is there on the first frame of
 * it rather than somewhere in the middle.
 */
private suspend fun warm(
    context: android.content.Context,
    model: Any,
    decodePx: Int,
    blur: BlurTransformation,
) {
    runCatching {
        context.imageLoader.execute(
            ImageRequest.Builder(context)
                .data(if (model is String) artSource(model) else model)
                .size(decodePx)
                .transformations(blur)
                .allowHardware(false)
                .build(),
        )
    }
}

@Composable
private fun AmbientImage(
    model: Any,
    decodePx: Int,
    blur: BlurTransformation,
    scale: ContentScale,
    layer: GraphicsLayerScope.() -> Unit,
) {
    AsyncImage(
        model = ImageRequest.Builder(LocalContext.current)
            // Offline this is the file on the disk rather than the address it
            // came from; the same resolution the sharp copy uses.
            .data(if (model is String) artSource(model) else model)
            .size(decodePx)
            .transformations(blur)
            // A hardware bitmap cannot be read back and the blur reads every
            // pixel of it.
            .allowHardware(false)
            // Off deliberately: the fade between two covers is the one above,
            // which knows about both of them. Coil's own also skips itself on a
            // cache hit, so with it on a prefetched cover arrives as a cut.
            .crossfade(false)
            .build(),
        contentDescription = null,
        // Stretched to the window rather than cropped to it, which is the
        // whole of why this reads as the cover carrying on.
        //
        // The cover is drawn across the top at its own proportions, and the
        // screen is much taller than that. Cropping to fill leaves the bottom
        // of the screen showing the middle of the sleeve, so the picture and
        // the field below it are two different parts of the same artwork
        // meeting at the fade — which is a seam however well the fade is made.
        // Filling the bounds keeps every row of this copy under the same row of
        // the sharp one and carries the last of it down to the foot of the
        // screen. The vertical stretch is real and, under this much blur,
        // unfindable.
        contentScale = scale,
        modifier = Modifier
            .fillMaxSize()
            .graphicsLayer(layer),
    )
}

/**
 * Enlargement from the top, where the sharp copy starts.
 *
 * Anything anchored at the centre slides the picture out of register with the
 * cover above it, and out of register is the whole of what a seam is.
 */
private val FootAnchor = TransformOrigin(0.5f, 0f)

/** And for the smear, which grows upward out of the bottom of its own box. */
private val SmearAnchor = TransformOrigin(0.5f, 1f)

/**
 * How far the copy below the cover is stretched.
 *
 * Very large on purpose. The band left in view is the last 1/[SMEAR] of the
 * picture, and it is drawn bottom-row-last — so the row that meets the seam is
 * not quite the row that ended the picture, and the difference between the two
 * is a line across the screen. At fifty that gap was two percent of the image
 * and findable; at four hundred it is a quarter of a percent, which is under
 * the blur. What is drawn is still the sleeve's own foot, varying across the
 * width the way the sleeve does.
 */
private const val SMEAR = 400f

/** How far past its own size the near copy is drawn. */
private const val NEAR_SCALE = 1.06f

/** How much of the near copy shows. */
private const val NEAR_ALPHA = 0.30f

/** How far the near copy drifts, as a fraction of the screen's height. */
private const val NEAR_TRAVEL = 0.014f

/** How long the drift takes to cross, one way. */
private const val DRIFT_MS = 12_000

/** How long the room takes to become a different room. */
private const val SWAP_MS = 720

/**
 * How long the change will wait for the new picture before going without it.
 *
 * Long enough for a cover to come off the network on a poor connection, short
 * enough that a cover which is not coming at all does not hold the screen on
 * the last record for longer than the song took to change.
 */
private const val READY_MS = 1_800

/** And the colour under it, which is slower still. */
private const val TONE_MS = 900

/** How long the field takes to become the clip's next colours. */
private const val CLIP_TONE_MS = 1_800

/** How far each colour is averaged into its neighbours, and how many times. */
private const val SPREAD_RADIUS = 4
private const val SPREAD_PASSES = 3

/**
 * A list of colours with the edges taken out of it.
 *
 * A box blur along the list, repeated: three passes of a running mean is close
 * enough to a gaussian that nothing in it can be found, and on two dozen
 * values it costs nothing. The ends are held rather than wrapped — the left of
 * the screen is not next to the right.
 */
private fun List<Color>.spread(passes: Int, radius: Int): List<Color> {
    if (size < 3 || radius < 1) return this
    var current = this
    repeat(passes) {
        current = current.mapIndexed { index, _ ->
            var r = 0f
            var g = 0f
            var b = 0f
            var count = 0
            for (offset in -radius..radius) {
                val at = (index + offset).coerceIn(0, current.lastIndex)
                val colour = current[at]
                r += colour.red
                g += colour.green
                b += colour.blue
                count++
            }
            Color(r / count, g / count, b / count)
        }
    }
    return current
}

/** How much the picture leaving grows, and the one arriving shrinks. */
private const val LEAVE_SWELL = 0.05f
private const val ARRIVE_SWELL = 0.06f

/** Blurred at decode, once per cover, and kept by Coil. */
private val FarBlur = BlurTransformation(radius = 10, passes = 1)
private val NearBlur = BlurTransformation(radius = 6, passes = 1)

/** How small each copy is decoded before it is blurred and stretched. */
private const val FAR_PX = 96
private const val NEAR_PX = 192
